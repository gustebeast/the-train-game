/** @noSelfInFile */
export declare class Color {
    readonly red: ColorValue;
    readonly green: ColorValue;
    readonly blue: ColorValue;
    readonly alpha: ColorValue;
    constructor(red: ColorValue, green: ColorValue, blue: ColorValue, alpha?: ColorValue);
    /** Create a string code for coloring text. */
    get code(): string;
    equals(other: Color): boolean;
    private playerColorIndex;
    /**
     * Returns the name of this color, if it is one of other player colors.
     * Otherwise returns 'unknown'.
     */
    get name(): string;
    /**
     * Returns the `playercolor` of this color, if it is one of the player
     * colors. Otherwise, returns `PLAYER_COLOR_RED`.
     */
    get playerColor(): playercolor;
    /**
     * Returns the color between this color and another via linear interpolation.
     * The provided factor should be between 0 and 1. Any color components
     * that are outside of the 0-255 range will be clamped.
     */
    lerp(other: Color, factor: number): Color;
}
export declare const color: (red: ColorValue, green: ColorValue, blue: ColorValue, alpha?: ColorValue) => Color;
/**
 * The player colors sorted by index. Does not include
 * neutrals colors.
 */
export declare const playerColors: Color[];
/** The names of players colors sorted by player index. */
export declare const playerColorNames: string[];
type Enumerate<N extends number, Acc extends number[] = []> = Acc['length'] extends N ? Acc[number] : Enumerate<N, [...Acc, Acc['length']]>;
/**
 * Generate a type that is represent a number ranging from [A, B)
 */
export type NumberRange<F extends number, T extends number> = Exclude<Enumerate<T>, Enumerate<F>>;
/**
 * The valid values for a color component.
 */
export type ColorValue = NumberRange<0, 256>;
export {};
